***
Path Generation from Xsens GNSS/INS modules
====
1. Requierements
 Xsens Device API (xda) for Python should be installed. It can be downloaded from https://www.xsens.com/software-downloads as MT Software Suit, in which you can find MT SDK for several programming languages.
 Once the xda for python is installed, feel free to play with the xsensLogData.py file to log the data in desired format.
 PathGenerate.py expects an excel file witch inculdes latitude as"LAT",longitude as "LON" and altitude as "ALT" paramaters in order to create a path.
